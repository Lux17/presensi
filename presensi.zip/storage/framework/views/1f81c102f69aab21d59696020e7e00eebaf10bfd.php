

<?php $__env->startSection('content'); ?>
<div>
    <div class="row">
        <div class="col-md-3">
            <div class="card shadow">
                <div class="card-body">
                    <h6 class="fs-6 fw-light">Data Role</h6>
                    <h4 class="fw-bold"><?php echo e($positionCount); ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow">
                <div class="card-body">
                    <h6 class="fs-6 fw-light">Data Anggota</h6>
                    <h4 class="fw-bold"><?php echo e($userCount); ?></h4>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\presensi\resources\views/dashboard/index.blade.php ENDPATH**/ ?>