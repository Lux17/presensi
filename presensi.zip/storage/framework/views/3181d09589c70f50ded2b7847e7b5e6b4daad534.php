

<?php $__env->startSection('buttons'); ?>
<div class="btn-toolbar mb-2 mb-md-0">
    <div>
        <a href="<?php echo e(route('positions.index')); ?>" class="btn btn-sm btn-light">
            <span data-feather="arrow-left-circle" class="align-text-bottom"></span>
            Kembali
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-7">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('position-create-form', [])->html();
} elseif ($_instance->childHasBeenRendered('ldahh6t')) {
    $componentId = $_instance->getRenderedChildComponentId('ldahh6t');
    $componentTag = $_instance->getRenderedChildComponentTagName('ldahh6t');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ldahh6t');
} else {
    $response = \Livewire\Livewire::mount('position-create-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('ldahh6t', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\presensi\resources\views/positions/create.blade.php ENDPATH**/ ?>